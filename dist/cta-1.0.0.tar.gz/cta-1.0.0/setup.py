import setuptools

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name='cta',
    version='1.0.0',
    author='Joe Rechenmacher',
    author_email='joe.rechenmacher@gmail.com',
    description='Python Wrapper for Chicago Transit Authority\'s BusTracker, TrainTracker, and CustomerAlerts APIs',
    license='GPU',
)
