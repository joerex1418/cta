# cta
A Python wrapper for interacting with the CTA Transit Feeds:  

**BusTrackerAPI**  
**TrainTrackerAPI**  
**CustomerAlertsAPI**



## API Wrapper Objects
- StaticFeed
- BusTracker
- TrainTracker
- CustomerAlerts

## BusTracker Objects
- BusRoute
- BusStop
- Bus


## TrainTracker Objects
- TrainRoute
- TrainStation
- Train